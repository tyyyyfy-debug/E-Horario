# E-horario V7

Aplicação Android para registo de horas.

## Planeamento
O leitor usa as cinco colunas de segunda a sexta e procura o colaborador escolhido dentro do bloco correspondente da obra. Não existem regras fixas para uma determinada semana, para evitar que um planeamento novo seja interpretado como o anterior.

Antes de importar, cada obra encontrada pode ser **editada** ou **apagada**. A edição permite alterar número/PAT, cliente, descrição, localidade (cidade/zona), equipa, coordenador e viatura.

## GitHub Mobile
Na raiz do repositório devem ser colocados `codemagic.yaml` e `project.zip`.
