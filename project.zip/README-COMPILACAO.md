# Horas Daniel — pacote de compilação

Esta versão foi preparada para carregamento pelo GitHub através do telemóvel.

## Funcionalidades corrigidas
- Impressão final através do sistema de impressão Android, em A4 horizontal.
- Leitura nativa do PDF de planeamento no Android, sem depender do PDF.js da Internet.
- Pesquisa pelo nome do colaborador escolhido.
- Leitura por dia/coluna e identificação das obras associadas ao colaborador.
- Extração dos dados disponíveis do planeamento: obra/PAT, cliente, descrição/localidade, equipa, coordenador e viatura.
- Data da semana extraída do cabeçalho do planeamento.
- Campos da folha deixam de reconstruir a linha a cada letra: o teclado não deve fechar durante a escrita.
- Cada célula tem botão `⋮` com Copiar, Colar e sugestões de preenchimento.
- Catálogo de obras com linha de edição diretamente na tabela, sem pop-ups.
- Mantém edição, arquivar/reativar, eliminar, duplicar e arrastar linhas.

## Compilação no Codemagic
O workflow usa `mac_mini_m2`, que é a máquina incluída nos minutos gratuitos das contas individuais do Codemagic. As máquinas Linux X2 exigem billing ativado.

O repositório simplificado contém apenas `codemagic.yaml` e `project.zip`. O workflow extrai o projeto e executa `gradle assembleDebug`.
