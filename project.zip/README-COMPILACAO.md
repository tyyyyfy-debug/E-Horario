# E-horario — compilação Android

O projeto é um Android WebView com leitor de planeamento PDF nativo através de PDFBox Android.

## Codemagic pelo telemóvel
Na raiz do repositório GitHub devem ficar apenas:
- codemagic.yaml
- project.zip

O workflow usa mac_mini_m2 e extrai `project.zip` antes de executar `gradle assembleDebug`.

## Leitura do planeamento
O leitor está adaptado ao modelo fixo dos planeamentos semanais enviados: cinco colunas de segunda a sexta, com zona de colaboradores, obra/descrição/localidade, coordenador e viatura.

A aplicação associa cada ocorrência do colaborador à obra mais próxima e não à obra imediatamente acima/abaixo. Também preserva vários números da mesma linha, como `26-0149 / 26-0273`.
