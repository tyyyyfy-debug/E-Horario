package com.danielveiga.horas;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.*;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.text.Normalizer;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private Uri selectedPdfUri;
    private static final int FILE_PICKER = 1001;
    private static final int MIC_PERMISSION = 1002;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        PDFBoxResourceLoader.init(getApplicationContext());
        webView = new WebView(this);
        webView.setLayoutParams(new ViewGroup.LayoutParams(-1,-1));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(uploadCallback!=null) uploadCallback.onReceiveValue(null);
                uploadCallback=cb;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/pdf");
                try { i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); } catch(Exception ignored) {}
                startActivityForResult(i,FILE_PICKER);
                return true;
            }
            @Override public void onPermissionRequest(PermissionRequest request){ runOnUiThread(() -> request.grant(request.getResources())); }
        });
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC_PERMISSION);
    }

    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==FILE_PICKER){
            Uri uri=(res==Activity.RESULT_OK&&data!=null)?data.getData():null;
            if(uri!=null){
                selectedPdfUri=uri;
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            }
            Uri[] r=uri!=null?new Uri[]{uri}:null;
            if(uploadCallback!=null){uploadCallback.onReceiveValue(r);uploadCallback=null;}
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void parsePlanning(final String employee){
            final Uri uri=selectedPdfUri;
            if(uri==null){
                runOnUiThread(() -> webView.evaluateJavascript("window.onNativePlanParsedError('Nenhum PDF selecionado')", null));
                return;
            }
            new Thread(() -> {
                try {
                    JSONArray result = parsePdf(uri, employee);
                    String json = result.toString().replace("\\", "\\\\").replace("'", "\\'");
                    runOnUiThread(() -> webView.evaluateJavascript("window.onNativePlanParsed('"+json+"')", null));
                } catch(Exception e){
                    String rawMsg = e.getMessage()==null?e.toString():e.getMessage();
                    final String msg = rawMsg.replace("\\","\\\\").replace("'","\\'").replace("\n"," ");
                    runOnUiThread(() -> webView.evaluateJavascript("window.onNativePlanParsedError('"+msg+"')", null));
                }
            }).start();
        }

        @JavascriptInterface public void printFinal(){
            runOnUiThread(() -> {
                try {
                    PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                    String job="Registo de Horas Colaborador - Daniel Veiga";
                    PrintAttributes attrs=new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    pm.print(job, webView.createPrintDocumentAdapter(job), attrs);
                } catch(Exception e){ webView.evaluateJavascript("alert('Não foi possível abrir a impressão: '+"+JSONObject.quote(e.getMessage())+")", null); }
            });
        }
    }

    private static class Word { String text; float x,y; Word(String t,float xx,float yy){text=t;x=xx;y=yy;} }
    private static class Line { float y,x; String text; List<Word> words=new ArrayList<>(); Line(float yy){y=yy;} }

    private static class CoordinateStripper extends PDFTextStripper {
        final List<Word> words=new ArrayList<>();
        CoordinateStripper() throws Exception { super(); setSortByPosition(true); }
        @Override protected void writeString(String string, List<TextPosition> positions) {
            StringBuilder cur=new StringBuilder(); float sx=0,sy=0,lastX=0;
            for(TextPosition tp:positions){
                String u=tp.getUnicode();
                if(u==null) continue;
                for(int i=0;i<u.length();i++){
                    char ch=u.charAt(i);
                    float x=tp.getXDirAdj() + (i * tp.getWidthDirAdj()/Math.max(1,u.length()));
                    float y=tp.getYDirAdj();
                    if(Character.isWhitespace(ch)){
                        if(cur.length()>0){ words.add(new Word(cur.toString(),sx,sy)); cur.setLength(0); }
                    } else {
                        if(cur.length()==0){ sx=x; sy=y; }
                        cur.append(ch); lastX=x;
                    }
                }
            }
            if(cur.length()>0) words.add(new Word(cur.toString(),sx,sy));
        }
    }

    private JSONArray parsePdf(Uri uri, String employee) throws Exception {
        String employeeRaw = employee == null || employee.trim().isEmpty() ? "Daniel Veiga" : employee.trim();
        String emp = norm(employeeRaw);
        JSONArray out = new JSONArray();
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("Não foi possível abrir o PDF");
        PDDocument doc = PDDocument.load(in);
        try {
            for (int pageIndex = 0; pageIndex < doc.getNumberOfPages(); pageIndex++) {
                String weekStart = findWeekStart(doc, pageIndex);
                CoordinateStripper stripper = new CoordinateStripper();
                stripper.setStartPage(pageIndex + 1);
                stripper.setEndPage(pageIndex + 1);
                stripper.getText(doc);
                List<Word> words = stripper.words;

                // O modelo de planeamento enviado tem sempre 5 colunas de dia,
                // com cerca de 228 pontos por coluna.
                float[] dayStarts = {25.0f, 253.0f, 481.0f, 709.0f, 938.0f};
                float[] dayEnds   = {242.0f, 470.0f, 698.0f, 926.0f, 1158.0f};
                for (int day = 0; day < 5; day++) {
                    float lo = dayStarts[day];
                    float hi = dayEnds[day];
                    List<Word> col = new ArrayList<>();
                    for (Word w : words) if (w.x >= lo && w.x < hi) col.add(w);
                    List<Line> lines = makeLines(col);

                    // Primeiro localizamos todas as linhas que contêm uma obra/PAT.
                    // Depois associamos a linha ao colaborador mais próximo. Isto é
                    // importante neste modelo porque o nome do colaborador pode ficar
                    // acima, abaixo ou na mesma linha do número da obra.
                    List<CodeGroup> groups = makeCodeGroups(lines);
                    java.util.HashSet<CodeGroup> assignedGroups = new java.util.HashSet<>();
                    // Fazemos a associação no sentido colaborador -> obra. Assim, um
                    // nome que esteja entre duas obras é ligado apenas à obra mais
                    // próxima, evitando falsos positivos como a obra imediatamente
                    // acima do colaborador.
                    for (Line employeeLine : lines) {
                        if (!lineContainsEmployee(employeeLine.text, emp)) continue;
                        CodeGroup bestGroup = null;
                        float bestDistance = Float.MAX_VALUE;
                        for (CodeGroup group : groups) {
                            if (assignedGroups.contains(group)) continue;
                            float d = Math.abs(group.centerY() - employeeLine.y);
                            if (d <= 40f && d < bestDistance) {
                                bestDistance = d;
                                bestGroup = group;
                            }
                        }
                        if (bestGroup == null) continue;
                        assignedGroups.add(bestGroup);

                        JSONObject obj = extractRecord(day, bestGroup, employeeLine, lines, lo, hi, employeeRaw);
                        obj.put("page", pageIndex + 1);
                        if (weekStart != null) obj.put("date", addDays(weekStart, day));
                        out.put(obj);
                    }
                }
            }
        } finally {
            try { doc.close(); } catch (Exception ignored) {}
            try { in.close(); } catch (Exception ignored) {}
        }

        // Uma linha do planeamento pode conter mais do que um código (por exemplo
        // 26-0149 / 26-0273). Mantemos todos os códigos e eliminamos duplicados.
        LinkedHashMap<String, JSONObject> unique = new LinkedHashMap<>();
        for (int i = 0; i < out.length(); i++) {
            JSONObject o = out.getJSONObject(i);
            String k = o.getInt("day") + "|" + norm(o.getString("work"));
            if (!unique.containsKey(k)) unique.put(k, o);
        }
        JSONArray result = new JSONArray();
        for (JSONObject o : unique.values()) result.put(o);
        return result;
    }

    private static class CodeGroup {
        final List<Line> lines = new ArrayList<>();
        final List<String> codes = new ArrayList<>();
        float centerY() {
            if (lines.isEmpty()) return 0;
            float sum = 0;
            for (Line l : lines) sum += l.y;
            return sum / lines.size();
        }
        float minY() { float v = Float.MAX_VALUE; for (Line l : lines) v = Math.min(v, l.y); return v; }
        float maxY() { float v = -Float.MAX_VALUE; for (Line l : lines) v = Math.max(v, l.y); return v; }
    }

    private static List<CodeGroup> makeCodeGroups(List<Line> lines) {
        List<CodeGroup> groups = new ArrayList<>();
        for (Line line : lines) {
            List<String> codes = findAllWorks(line.text);
            if (codes.isEmpty()) continue;
            CodeGroup target = null;
            for (CodeGroup g : groups) {
                if (Math.abs(g.maxY() - line.y) <= 12f || Math.abs(g.minY() - line.y) <= 12f) {
                    target = g; break;
                }
            }
            if (target == null) {
                target = new CodeGroup();
                groups.add(target);
            }
            target.lines.add(line);
            for (String code : codes) if (!target.codes.contains(code)) target.codes.add(code);
        }
        Collections.sort(groups, Comparator.comparingDouble(CodeGroup::centerY));
        return groups;
    }

    private static Line nearestEmployeeLine(List<Line> lines, float y, String employee, float maxDistance) {
        Line best = null;
        float bestDistance = Float.MAX_VALUE;
        for (Line line : lines) {
            if (!lineContainsEmployee(line.text, employee)) continue;
            float d = Math.abs(line.y - y);
            if (d <= maxDistance && d < bestDistance) {
                best = line;
                bestDistance = d;
            }
        }
        return best;
    }

    private static boolean lineContainsEmployee(String text, String employee) {
        String t = norm(text);
        String e = norm(employee);
        if (e.isEmpty()) return false;
        if (t.contains(e)) return true;
        String[] parts = e.split(" ");
        if (parts.length >= 2) {
            for (int i = 0; i < parts.length - 1; i++) {
                if (t.contains(parts[i] + " " + parts[i + 1])) return true;
            }
        }
        return false;
    }

    private String findWeekStart(PDDocument doc, int pageIndex) throws Exception {
        PDFTextStripper s = new PDFTextStripper();
        s.setStartPage(pageIndex + 1); s.setEndPage(pageIndex + 1); s.setSortByPosition(true);
        String text = s.getText(doc);
        Matcher m = Pattern.compile("(?i)Semana\\s+\\d+\\s*-\\s*(\\d{1,2})\\s+de\\s+([A-Za-zÀ-ÿ]+).*?(\\d{4})").matcher(text);
        if (!m.find()) return null;
        int day = Integer.parseInt(m.group(1));
        int year = Integer.parseInt(m.group(3));
        int month = monthNumber(m.group(2));
        if (month < 1) return null;
        return String.format(Locale.US, "%04d-%02d-%02d", year, month, day);
    }

    private int monthNumber(String m) {
        String x = norm(m);
        String[] names = {"janeiro","fevereiro","marco","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro"};
        for (int i = 0; i < names.length; i++) if (x.equals(names[i])) return i + 1;
        return -1;
    }

    private String addDays(String iso, int days) {
        try {
            String[] p = iso.split("-");
            Calendar c = Calendar.getInstance();
            c.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]), 12, 0, 0);
            c.add(Calendar.DAY_OF_MONTH, days);
            return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
        } catch (Exception e) { return iso; }
    }

    private JSONObject extractRecord(int day, CodeGroup group, Line employeeLine, List<Line> lines, float lo, float hi, String employee) throws Exception {
        JSONObject o = new JSONObject();
        o.put("day", day);
        o.put("work", joinCodes(group.codes));
        o.put("client", "");
        o.put("description", "");
        o.put("location", "");
        o.put("team", "");
        o.put("coord", "");
        o.put("vehicle", "");

        float cy = group.centerY();

        // Equipa: tudo o que aparece na zona esquerda da mesma linha/bloco,
        // retirando o colaborador escolhido e os marcadores "1".
        List<String> teamParts = new ArrayList<>();
        for (Line l : lines) {
            if (l.y < group.minY() - 32 || l.y > group.maxY() + 4) continue;
            StringBuilder left = new StringBuilder();
            for (Word w : l.words) {
                if (w.x >= lo + 105) continue;
                String token = w.text.trim();
                if (token.isEmpty() || token.matches("1")) continue;
                if (left.length() > 0) left.append(' ');
                left.append(token);
            }
            String part = left.toString().trim();
            if (part.isEmpty()) continue;
            String empNorm = norm(employee);
            if (!empNorm.isEmpty()) {
                if (norm(part).equals(empNorm)) {
                    part = "";
                } else {
                    String[] empParts = employee.trim().split("\\s+");
                    if (empParts.length >= 2) {
                        part = part.replaceAll("(?i)" + Pattern.quote(employee.trim()), "").replaceAll("\\s+", " ").trim();
                    }
                }
            }
            if (!part.isEmpty() && !norm(part).equals("1") && !teamParts.contains(part)) teamParts.add(part);
        }
        o.put("team", String.join(", ", teamParts));

        // Informação da obra fica à direita. Neste modelo, as linhas antes do
        // código são: cliente, descrição (opcional), localidade (opcional).
        List<String> detailLines = new ArrayList<>();
        for (Line l : lines) {
            if (l.y < group.minY() - 38 || l.y >= group.minY() - 1) continue;
            String t = lineTextInX(l, lo + 105, hi - 20).trim();
            if (t.isEmpty()) continue;
            if (!findAllWorks(t).isEmpty()) continue;
            if (norm(t).startsWith("do -")) continue;
            if (t.matches("(?i)^[A-Z]{2}$")) continue;
            if (!detailLines.contains(t)) detailLines.add(t);
        }

        String client = "", description = "", location = "";
        if (!detailLines.isEmpty()) {
            String first = detailLines.get(0);
            Matcher split = Pattern.compile("^(.+?)\\s*-\\s*(.+)$").matcher(first);
            if (split.matches()) {
                client = split.group(1).trim();
                description = split.group(2).trim();
            } else {
                client = first;
            }
            if (detailLines.size() >= 2) {
                if (detailLines.size() == 2) {
                    if (description.isEmpty()) location = detailLines.get(1);
                    else location = detailLines.get(1);
                } else {
                    if (description.isEmpty()) description = detailLines.get(1);
                    else description = description + " | " + detailLines.get(1);
                    location = detailLines.get(detailLines.size() - 1);
                }
            }
        }
        o.put("client", client);
        o.put("description", description);
        o.put("location", location);

        // Coordenador: neste modelo aparece no fundo do bloco da obra.
        String coord = "";
        float bestCoord = Float.MAX_VALUE;
        for (Line l : lines) {
            if (l.y < group.maxY() || l.y > group.maxY() + 42) continue;
            String t = l.text.trim();
            if (norm(t).startsWith("do -")) {
                float d = l.y - group.maxY();
                if (d < bestCoord) { bestCoord = d; coord = t.replaceFirst("(?i)^DO\\s*-\\s*", "").trim(); }
            }
        }
        o.put("coord", coord);

        // Viatura(s): zona mais à direita do bloco.
        LinkedHashMap<String, Boolean> vehicles = new LinkedHashMap<>();
        String[] knownVehicles = {"DZ", "UI", "HP", "BA", "ZX", "AC", "US"};
        for (Line l : lines) {
            if (l.y < group.minY() - 18 || l.y > group.maxY() + 22) continue;
            for (Word w : l.words) {
                if (w.x < hi - 90 || w.x > hi + 4) continue;
                String v = w.text.trim().toUpperCase(Locale.ROOT);
                for (String known : knownVehicles) if (known.equals(v)) vehicles.put(v, true);
            }
        }
        StringBuilder vehicle = new StringBuilder();
        for (String v : vehicles.keySet()) { if (vehicle.length() > 0) vehicle.append(" / "); vehicle.append(v); }
        o.put("vehicle", vehicle.toString());

        // A coluna de localidade deve representar sempre uma cidade/zona (ex.: Nazaré),
        // nunca uma descrição interna da obra (ex.: "AVAC Piso 2"). Para as obras
        // conhecidas do catálogo, a localidade guardada no catálogo tem prioridade.
        String canonicalLocation = canonicalLocationForWork(group.codes);
        if (!canonicalLocation.isEmpty()) {
            location = canonicalLocation;
            o.put("location", location);
        }

        // PAT 3897 (e outros casos semelhantes) pode ter a localidade depois do código.
        if (location.isEmpty()) {
            for (Line l : lines) {
                if (l.y <= group.maxY() || l.y > group.maxY() + 18) continue;
                String t = lineTextInX(l, lo + 105, hi - 20).trim();
                if (t.isEmpty() || !findAllWorks(t).isEmpty() || norm(t).startsWith("do -")) continue;
                if (t.matches("(?i)^[A-Z]{2}$")) continue;
                location = t;
                break;
            }
            o.put("location", location);
        }
        return o;
    }

    /**
     * Localidade canónica por obra. A localidade é uma cidade/zona geográfica,
     * separada da descrição técnica da intervenção.
     */
    private static String canonicalLocationForWork(List<String> codes) {
        for (String raw : codes) {
            String code = norm(raw);
            if (code.equals("26-0113")) return "Oeiras";
            if (code.equals("PAT 3897")) return "Leiria";
            if (code.equals("25-0363")) return "Burinhosa";
            if (code.equals("24-0562")) return "Vau";
            if (code.equals("26-0149") || code.equals("26-0273")) return "Nazaré";
        }
        return "";
    }

    private static String joinCodes(List<String> codes) {
        StringBuilder sb = new StringBuilder();
        for (String c : codes) { if (sb.length() > 0) sb.append(" / "); sb.append(c); }
        return sb.toString();
    }

    private String lineTextInX(Line l, float x1, float x2) {
        StringBuilder sb = new StringBuilder();
        for (Word w : l.words) if (w.x >= x1 && w.x < x2) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(w.text);
        }
        return sb.toString();
    }

    private static List<Line> makeLines(List<Word> words) {
        List<Word> sorted = new ArrayList<>(words);
        Collections.sort(sorted, (a,b) -> { int c = Float.compare(a.y,b.y); return c != 0 ? c : Float.compare(a.x,b.x); });
        List<Line> lines = new ArrayList<>();
        for (Word w : sorted) {
            Line hit = null;
            for (Line l : lines) if (Math.abs(l.y - w.y) <= 2.5f) { hit = l; break; }
            if (hit == null) { hit = new Line(w.y); lines.add(hit); }
            hit.words.add(w);
        }
        for (Line l : lines) {
            Collections.sort(l.words, Comparator.comparingDouble(a -> a.x));
            StringBuilder sb = new StringBuilder();
            float minX = Float.MAX_VALUE;
            for (Word w : l.words) { if (sb.length() > 0) sb.append(' '); sb.append(w.text); minX = Math.min(minX, w.x); }
            l.x = minX == Float.MAX_VALUE ? 0 : minX;
            l.text = sb.toString().trim();
        }
        Collections.sort(lines, Comparator.comparingDouble(a -> a.y));
        return lines;
    }

    private static List<String> findAllWorks(String t) {
        List<String> result = new ArrayList<>();
        Matcher m = Pattern.compile("(?i)\\b(\\d{2}-\\d{4})\\b").matcher(t);
        while (m.find()) if (!result.contains(m.group(1))) result.add(m.group(1));
        Matcher p = Pattern.compile("(?i)\\bPAT\\s+(\\d+)\\b").matcher(t);
        while (p.find()) {
            String v = "PAT " + p.group(1);
            if (!result.contains(v)) result.add(v);
        }
        return result;
    }

    private static String findWork(String t) {
        List<String> all = findAllWorks(t);
        return all.isEmpty() ? null : all.get(0);
    }

    private static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        return n.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
    }
    @Override public void onBackPressed(){ if(webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
